package Runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
    features = "src/test/resource/Features",
    glue = "stepdef",
    tags = "@set1 or @set2",
    plugin = {"pretty", "html:target/cucumber-reports.html"}

)
public class testrunner extends AbstractTestNGCucumberTests {
}

//we don't need to create' test package for testng this is the use for testng