Feature: User Sign Up

@set6
Scenario: Valid Sign Up
Given the user is on the Sign Up page
And  the user enters a singup valid username "a38s340@gmail"
And the user enters a singup valid password "ValidPass123"
And the user clicks the Sign Up button
Then the user should see a success message or be redirected to the homepage







@se4
Scenario: Invalid Sign Up - Empty Username
  Given the user is on the Sign Up page
  When the user enters username "" and password "ValidPass123"
  And the user clicks the Sign Up button
  Then the user should see message "Username is required"

@set5
Scenario: Invalid Sign Up - Empty Password
  Given the user is on the Sign Up page
  When the user enters username "abep2809" and password ""
  And the user clicks the Sign Up button
  Then the user should see message "Password is required"

@set4
Scenario: Invalid Sign Up - Both Fields Empty
  Given the user is on the Sign Up page
  When the user enters username "" and password ""
  And the user clicks the Sign Up button
  Then the user should see message "Username and Password are required"